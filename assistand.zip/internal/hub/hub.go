package hub

import (
	"fmt"
	"sync"
)

type Connection interface {
	SendMessage(message []byte) error
	Close() error
}

type Hub struct {
	connections map[string]Connection
	mu          sync.Mutex
}

func NewHub() *Hub {
	return &Hub{
		connections: make(map[string]Connection),
	}
}

func (h *Hub) Register(sessionID string, conn Connection) {
	h.mu.Lock()
	defer h.mu.Unlock()
	h.connections[sessionID] = conn
}

func (h *Hub) Unregister(sessionID string) {
	h.mu.Lock()
	defer h.mu.Unlock()
	if conn, ok := h.connections[sessionID]; ok {
		conn.Close()
		delete(h.connections, sessionID)
	}
}

func (h *Hub) SendMessage(sessionID string, message []byte) error {
	h.mu.Lock()
	defer h.mu.Unlock()
	conn, ok := h.connections[sessionID]
	if !ok {
		return fmt.Errorf("no connection found for session_id %s", sessionID)
	}
	return conn.SendMessage(message)
}
