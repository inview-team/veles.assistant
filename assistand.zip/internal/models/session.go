package models

type Session struct {
	ID    string
	Token string
	State SessionState
}

type SessionState struct {
}
