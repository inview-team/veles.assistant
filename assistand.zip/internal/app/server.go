package app

import (
	"context"
	"fmt"
	"net"
	"net/http"
	"sync"

	"github.com/Korpenter/assistand/internal/config"
	"github.com/gorilla/websocket"
	log "github.com/sirupsen/logrus"
)

const (
	wsBufferSizeLimitInBytes = 1024
)

type SessionHandler interface {
	HandleMessage(rawMsg []byte, wsConn *websocket.Conn) ([]byte, error)
}

type App struct {
	config         *config.Config
	sessionHandler SessionHandler
	wsSrv          *http.Server
	wsUpgrader     websocket.Upgrader
}

func NewApp(cfg *config.Config, sessionHandler SessionHandler) *App {
	app := &App{
		config:         cfg,
		sessionHandler: sessionHandler,
	}
	return app
}

func (a *App) Start() {
	a.startWS()
}

func (a *App) Stop() error {
	if a.wsSrv != nil {
		if err := a.wsSrv.Shutdown(context.Background()); err != nil {
			return err
		}

		if err := a.wsSrv.Close(); err != nil {
			return err
		}
		a.wsSrv = nil
	}

	return nil
}

func (a *App) startWS() {
	log.Infof("starting websocket server")

	if a.wsSrv != nil {
		log.Errorf("websocket server already started")
		return
	}

	address := fmt.Sprintf("%s:%d", a.config.WebSocketHost, a.config.WebSocketPort)

	lis, err := net.Listen("tcp", address)
	if err != nil {
		log.Errorf("failed to create tcp listener: %v", err)
		return
	}

	mux := http.NewServeMux()
	mux.HandleFunc("/ws", a.handleWs)

	a.wsSrv = &http.Server{
		Handler: mux,
	}
	a.wsUpgrader = websocket.Upgrader{
		ReadBufferSize:  wsBufferSizeLimitInBytes,
		WriteBufferSize: wsBufferSizeLimitInBytes,
	}
	log.Infof("websocket server started: %s", address)
	if err := a.wsSrv.Serve(lis); err != nil {
		if err == http.ErrServerClosed {
			log.Infof("websocket server stopped")
			return
		}
		log.Errorf("closed websocket connection: %v", err)
		return
	}
}

func (a *App) handleWs(w http.ResponseWriter, req *http.Request) {
	a.wsUpgrader.CheckOrigin = func(r *http.Request) bool { return true }

	wsConn, err := a.wsUpgrader.Upgrade(w, req, nil)
	if err != nil {
		log.Error(fmt.Sprintf("Unable to upgrade to a WS connection, %s", err.Error()))

		return
	}

	defer func(ws *websocket.Conn) {
		err = ws.Close()
		if err != nil {
			log.Error(fmt.Sprintf("Unable to gracefully close WS connection, %s", err.Error()))
		}
	}(wsConn)

	log.Info("Websocket connection established")
	var mu sync.Mutex
	for {
		msgType, message, err := wsConn.ReadMessage()
		if err != nil {
			if websocket.IsCloseError(err, websocket.CloseGoingAway, websocket.CloseNormalClosure, websocket.CloseAbnormalClosure) {
				log.Info("Closing WS connection gracefully")
			} else {
				log.Error(fmt.Sprintf("Unable to read WS message, %s", err.Error()))
				log.Info("Closing WS connection with error")
			}

			break
		}

		if msgType == websocket.TextMessage {
			go func() {
				mu.Lock()
				defer mu.Unlock()
				resp, err := a.sessionHandler.HandleMessage(message, wsConn)
				if err != nil {
					log.Error(fmt.Sprintf("Unable to handle WS request, %s", err.Error()))
					_ = wsConn.WriteMessage(msgType, []byte(fmt.Sprintf("WS Handle error: %s", err.Error())))
				} else {
					_ = wsConn.WriteMessage(msgType, resp)
				}
			}()
		}
	}
}
